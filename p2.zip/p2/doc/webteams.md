# __***Dokumentation für das erste Webengeneering-Praktikum***__

Datum: 20.10.2017 Gruppe: I Team: Leon Beer

##Aufbau der Webanwendung

###Die Webanwendung mit dem Namen ***Webteams*** besteht aus drei verschiedenen Abschnitten:
+ Anwendungslogik (Python-Code)
+ Websitevisualisierung (HTML, CSS, Javascript)
+ Dateispeicherung (JSON)

Der ***Applikationsteil*** besteht wiederum aus 3 Dateien:

+ ***application.py***

	+ Herzstück bzw. Dreh und Angelpunkt des Programms, da alle Aktionen über die ihn weitergeleitet werden müssen. 
		Die anderen beiden Dateien (***view.py***, ***database.py***) sind als Objekte im Code referenziert.
		Die Datei hat Methoden zum Erstellen von neunen, bearbeiten und löschen von alten Einträgen und 
		der Speicherung dieder. In diesen Methoden werden wiederum Calls auf die anderen Datei aufgerufen
		und die Aufgaben somit weiter verteilt.
		
+ ***view.py***

	+ Erstellt Listen und Formulare nachdem diese aus der ***application.py*** aufgerufen und benutzt die Informationen die von
		dieser übergeben wurden. Um diese Listen/Formulare zu erstellen werden .tpl-Datei aus dem Visualisierungsabschnitt
		eingebunden die definieren wie die Seite ausehen soll. Anschließend werden die fertigen anzeigefähigen HTML-Abschnitten
		zurückgegeben.
		
+ ***database.py*** 
	
	+ Dient als Ersatz für eine Datenbank. Analog zu den Create/Update/Delete-Methoden der ***application.py*** werden 
		Methoden zur Änderung/Löschung oder Erstellung von Daten in der ***database.py*** aufgerufen, die diese Änderungen
		mit den übergebenen Informationen dann in der webteams.json-Datei speichert.
		Beim Aufruf jeglicher Seite wird auch die ***database.py*** angesprochen um die Daten aus der JSON-Datei auszulesen.

Der ***Websitevisualisierungsteil*** besteht aus 8 Dateien:

+ ***form0.tpl*** , ***form1.tpl*** und ***form2.tpl***
	
	+ Die ***formX.tpl***-Dateien sagen wie das Formular zur Bearbeiten oder Erstellen neuer Einträge aussehen sollen.
		
		+ ***form0.tpl*** ist der Kopf des Formular in dem nötige Header-Informationen(Titel, CSS/Javascript-Einbindung)definiert 
			werden
			
		+ In ***form1.tpl*** sind die Input-Felder definiert in denen man die Informationen einträgt.
			
		+ ***form2.tpl*** ist das Ende des Formulars/HTML-Dokuments. Es beinhaltet den Submit-Button für das
				Speicher-Formular und ein weiteres Formular womit man ohne Änderungen wieder auf die Startseite kommt (Abbrechen).
	
+ ***list0.tpl***, ***list1.tpl*** und ***list2.tpl***
		
	+ Die ***listX.tpl***-Dateien beschreiben wie die Liste aussehen soll in der alle Einträge mit allen Informationen augezählt werden.
		
		+ ***list0.tpl*** Der Anfang der Startseite mit allen nötigen Header-Informationen(Titel, CSS/Javascript-Einbindung etc.).
		
		+ ***list1.tpl*** enthält eine einzelne Tabellenspalte die nach bedarf wiederholt wird. In der Zeile werden die 
			Informationen für die Einträge angezeigt und zwei Buttons zur Bearbeitung und Löschung des Eintrags definiert.
		
		+ ***list2.tpl*** beendet die Tabelle und das HTML-Dokument und erzeugt zudem noch einen Link mit dem man einen Eintrag
			hinzufügen kann.
	
	+ In ***webteams.css*** werden die Style-Informationen zur Gestaltung der HTML-Elemente gespeichert.
	
	+ ***webteams.js*** ist die Javascript-Datei die die Funktion der Löschbestätigung beinhaltet. Die Funktion ruft bei erfolgreicher
		Ausführung anschließen die Delete-Methode der ***application.py*** auf.

Der ***Dateispeicherungsteil*** besteht aus 1 Datei:

+ In der ***webteams.json*** ist eine Map aufgebaut in der ein Index zur einen Array zugeordnet wird. In dem Array stehen die
		Informationen eines Eintrags. Die Datei wird von der ***database.py*** zur Datenverwaltung verwendet.
		
##Durchgeführte Ergänzungen:
	
+ ***application.py*** 
	
	+ Save-Methode
	
		+ Exception-Handling falls Seite ohne Parameter aufgerufen wird
		
		+ Ergänzung der Variablen für die Semesteranzahl
	
	+ Edit-Methode
		
		+ Ergänzung eines Verweis auf den Index wenn ein Eintrag erfolgreich abgespeichert wird

+  ***view.py***
	
	+ createList-Methode
		
		+ Ergänzung von Semesteranzahl-Variablen
	
	+ createForm-Methode
		
		+ Ergänzung von Semesteranzahl-Variablen
	
	+ readFile_p-Methode
		
		+ Anpassung der Auslese-Funktionen für Dateien

+ ***database.py***
	
	+ delete_px-Methode
		
		+ Methode implementiert
	
	+ getDefault_px-Methode
		
		+ Zwei Einträge für Semesteranzahl hinzugefügt
	
	+ readData_p-Methode
		
		+ Anpassung des Arrays um Platz für die Semesteranzahl zu machen
		
		+ Anpassung der Auslese-Funktionen für Dateien
	
	+ saveData_p-Methode
		
		+ Anpassung der Auslese-Funktionen für Dateien

+ ***form0.py***
	
	+ Keine Änderungen

+ ***form1.py***
	
	+ Hinzufügen der Einträge für die 1. und 2. Semesteranzahl
	
	+ Erstellen einer Tabelle und Einordnung der Input-Felder/Labels 

+ ***form2.py***
	
	+ Ergänzung einer zweiten form für den Abbruch Button die einen Verweis auch die Startseite hat.

+ ***list0.tpl***
	
	+ Ergänzung des Tabellenheaders für die Semesteranzahl

+ ***list1.tpl***
	
	+ Ergänzung der Semesteranzahl in der Tabellenzeile
	
	+ Hinterlegung des Löschen-Links mit der Javascript-Methode zur Sicherheits-Abfrage

+ ***list2.tpl***
	
	+ Keine Änderungen

+ ***webteams.js***
	
	+ Implementierung der Abfragen-Funktion für das Löschen-Links
	
	+ Auskommentierung der onload-Funktion

+ ***webteams.css***
	
	+ Implementierung der Style-Informationen
		
##Beschreibung des HTTP-Datenverkehrs	

### Beim Start der Anwendung:

+ Wenn man die Anwendung im Internetbrowsers aufruft wird ein HTTP-GET-Befehl auf die Adresse geschickt. Durch die GET-Anfrage 
	wird anschließend, wie in der ***server.py*** definiert, die Startklasse initialisiert. Also wird bei unserer
	Anwendung die ***application.py*** ausgeführt und initialisiert. Somit werden auch ***view.py*** und
	***database.py*** initialisiert. Anschließend wird der Index aufgerufen und somit die Anwendung gestartet.
	Bevor die Seite angezeigt wird, werden aber noch die ***webteams.js*** und ***webteams.css*** geladen, da sie am Anfang des
	HTML-Codes referenziert wurden. Auf diese wird dann auch mit einen HTTP-GET-Befehl zugegriffen.
		
###Beim Speichern von Formulardaten

+ Wenn man ein Formular abspeichern möchte und auf den ***Speichern***-Button klickt wird ein HTTP-POST-Befehl losgeschickt.
	In diesen HTTP-POST-Befehl stehen die zu speichernden Informationen mit ihren zugehörigen ID´s. Der POST wird
	anschließend an die ***application.py*** geschickt die diese Daten dann verarbeitet und speichert. Anschließend wird
	der Index wieder aufgerufen und die auf der Website die Startseite angezeigt.