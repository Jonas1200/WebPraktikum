# coding: utf-8

# sehr einfache Erzeugung des Markups für vollständige Seiten
# jeweils 3 Abschnitte:
# - begin
# - content
# - end

# bei der Liste wird der content-Abschnitt wiederholt
# beim Formular nicht
import codecs
import os.path
import string

#----------------------------------------------------------
class View_cl(object):
#----------------------------------------------------------
	#-------------------------------------------------------
	def __init__(self):
	#-------------------------------------------------------
		pass
	#-------------------------------------------------------
	def createList_px(self):
	#-------------------------------------------------------
		# hier müsste noch eine Fehlerbehandlung ergänzt werden !
		markup_s=''
		markup_s+=self.readFile_p('list0.tpl')
		markup_s+=self.readFile_p('list2.tpl')
		return markup_s
	#-------------------------------------------------------
	def createAb(self):
	#-------------------------------------------------------
		print('createAb')
		markup_s=''
		markup_s += self.readFile_p('form0.tpl')
		return markup_s
	#-------------------------------------------------------
	def createMit(self):
	#-------------------------------------------------------
		markup_s=''
		markup_s += self.readFile_p('form1.tpl')
		return markup_s
	#-------------------------------------------------------
	def formAbsolvent(self, id, data_opl):
	#-------------------------------------------------------
		markup_s=''
		markup_s += self.readFile_p('Abform0.tpl')
		markupV_s=self.readFile_p('Abform1.tpl')
		lineT_o=string.Template(markupV_s)
		markup_s += lineT_o.safe_substitute (email_s=data_opl[0]
		, passwort_s=data_opl[1]
		, nachname_s=data_opl[2]
		, vorname_s=data_opl[3]
		, matrikelnummer_s=data_opl[4]
		,begleitpersonen_s=data_opl[5]
		,thema_s=data_opl[6]
		,art_s=data_opl[7]
		, id_s=id
		)
		
		markup_s+=self.readFile_p('Abform2.tpl')
		
		markupV_s2=self.readFile_p('Abform3.tpl')
		lineT_o=string.Template(markupV_s2)
		markup_s += lineT_o.safe_substitute (id_s=id)
		
		markup_s+=self.readFile_p('Abform4.tpl')
		#Wie in createForm
		return markup_s
	#-------------------------------------------------------
	def createForm_px(self, id_spl, data_opl):
	#-------------------------------------------------------
		# hier müsste noch eine Fehlerbehandlung ergänzt werden !
		markup_s=''
		markup_s += self.readFile_p('form0.tpl')
		markupV_s=self.readFile_p('form1.tpl')
		lineT_o=string.Template(markupV_s)
		markup_s += lineT_o.safe_substitute (name1_s=data_opl[0]# HIER müssen Sie eine Ergänzung vornehmen
		, vorname1_s=data_opl[1]
		, matrnr1_s=data_opl[2]
		, semanz1_s=data_opl[3]
		, name2_s=data_opl[4]
		, vorname2_s=data_opl[5]
		, matrnr2_s=data_opl[6]
		, semanz2_s=data_opl[7]
		, id_s=id_spl
		)
		markup_s+=self.readFile_p('form2.tpl')
		return markup_s
	#-------------------------------------------------------
	def readFile_p(self, fileName_spl):
	#-------------------------------------------------------
		content_s = ''
		
		#fp_o = codecs.open('D:\web\p1\webteams\data\webteams.json','r','utf-8')
		s = 'D:\web\p2\content\\'
		s += fileName_spl
		#with codecs.open(os.path.join('content', fileName_spl),'r','utf-8')as fp_o:
		with codecs.open(s,'r','utf-8')as fp_o:
			content_s = fp_o.read()
		return content_s
# EOF

