//function confirmDelete_p(event_opl){
function confirmDelete_p(id){

	//alert("Sie befinden sich auf dem Host " + window.location.host);
	//if((event_opl.target.tagName.toLowerCase()=='a')&&(event_opl.target.className=="clDelete")){
		// Klick auf Link zum Löschen
		// Ihre Ergänzung
		var bool;
		bool = confirm("Wirklich loeschen?");
	
		if(bool){
			//var id = event_opl.target.id;
			
			location.href = "/delete/"+id;
			
		}
		
		
	//}
}

/*
window.onload=function(){
	letbody_o=document.getElementsByTagName('body')[0];
	body_o.addEventListener('click',confirmDelete_p,false);
}
*/


function anmeldenAb(){

	//alert("Sie befinden sich auf dem Host " + window.location.host);
	//if((event_opl.target.tagName.toLowerCase()=='a')&&(event_opl.target.className=="clDelete")){
		// Klick auf Link zum Löschen
		// Ihre Ergänzung
		
		//var bool;
		//bool = confirm("Wirklich loeschen?");
	
		//if(bool){
			//var id = event_opl.target.id;
			confirm("hier");
			location.href = "/anmeldenAb/";
			
	//	}
		
		
	//}
}
function anmeldenMit(){

	//alert("Sie befinden sich auf dem Host " + window.location.host);
	//if((event_opl.target.tagName.toLowerCase()=='a')&&(event_opl.target.className=="clDelete")){
		// Klick auf Link zum Löschen
		// Ihre Ergänzung
		
		//var bool;
		//bool = confirm("Wirklich loeschen?");
	
		//if(bool){
			//var id = event_opl.target.id;
			
			location.href = "/anmeldenMit/";
			
	//	}
		
		
	//}
}

function erstCh(){
	document.getElementById("tauscher").innerHTML = ""+
		"	<form id=\"absolForm\" action=\"/neuAb/\" method=\"POST\">		"+
		"		<table border=\"1\">"+
					
					
			"		<tr>"+
				"	<td>"+
				"	<div>"+
				"		<label for=\"email_s\">E-Mail</label>"+
				"	</div>"+
			"		</td>"+
			"		<td>"+
			"		<div>"+
					"	<input type=\"text\" id=\"email_s\" name=\"email_s\" required/>"+
				"	</div>"+
					"</td>"+
					"</tr>"+
					
				"	<tr>"+
				"	<td>"+
				"	<div>"+
				"		<label for=\"passwort1_s\">1. Passwort</label>"+
				"	</div>"+
				"	</td>"+
				"	<td>"+
				"	<div>"+
				"		<input type=\"text\" id=\"passwort1_s\" name=\"passwort1_s\" required/>"+
				"	</div>"+
				"	</td>"+
				"	</tr>"+
					
				"	<tr>"+
				"	<td>"+
				"	<div>"+
					"	<label for=\"passwort2_s\">2. Passwort</label>"+
				"	</div>"+
				"	</td>"+
				"	<td>"+
				"	<div>"+
				"		<input type=\"text\" id=\"passwort2_s\" name=\"passwort2_s\" required/>"+
				"	</div>"+
				"	</td>"+
				"	</tr>"+
	
				
				"</table>"+
				
				"<div>"+
				"	<input type=\"submit\" value=\"Speichern\"/>"+
				"</div>"+
			"</form>";
}

function zweiCh(){
	document.getElementById("tauscher").innerHTML = "" +
			"<form id=\"absolForm\" action=\"/bearbeitenAb/\" method=\"POST\">		"+
				"<table border=\"1\">"+
					
					
					"		<tr>"+
				"	<td>"+
				"	<div>"+
				"		<label for=\"email_s\">E-Mail</label>"+
				"	</div>"+
			"		</td>"+
			"		<td>"+
			"		<div>"+
					"	<input type=\"text\" id=\"email_s\" name=\"email_s\" required/>"+
				"	</div>"+
					"</td>"+
					"</tr>"+
					
				"	<tr>"+
				"	<td>"+
				"	<div>"+
				"		<label for=\"passwort1_s\">Passwort</label>"+
				"	</div>"+
				"	</td>"+
				"	<td>"+
				"	<div>"+
				"		<input type=\"text\" id=\"passwort_s\" name=\"passwort_s\" required/>"+
				"	</div>"+
				"	</td>"+
				"	</tr>"+
					
					
				"</table>"+
				
				"<div>"+
					"<input type=\"submit\" value=\"Speichern\"/>"+
				"</div>"+
			"</form>";
}


function erstMit(){
	document.getElementById("tauscher").innerHTML = ""+
		"	<form id=\"absolForm\" action=\"/neuMit/\" method=\"POST\">		"+
		"		<table border=\"1\">"+
					
					
			"		<tr>"+
				"	<td>"+
				"	<div>"+
				"		<label for=\"email_s\">E-Mail</label>"+
				"	</div>"+
			"		</td>"+
			"		<td>"+
			"		<div>"+
					"	<input type=\"text\" id=\"email_s\" name=\"email_s\" required/>"+
				"	</div>"+
					"</td>"+
					"</tr>"+
					
				"	<tr>"+
				"	<td>"+
				"	<div>"+
				"		<label for=\"passwort1_s\">1. Passwort</label>"+
				"	</div>"+
				"	</td>"+
				"	<td>"+
				"	<div>"+
				"		<input type=\"text\" id=\"passwort1_s\" name=\"passwort1_s\" required/>"+
				"	</div>"+
				"	</td>"+
				"	</tr>"+
					
				"	<tr>"+
				"	<td>"+
				"	<div>"+
					"	<label for=\"passwort2_s\">2. Passwort</label>"+
				"	</div>"+
				"	</td>"+
				"	<td>"+
				"	<div>"+
				"		<input type=\"text\" id=\"passwort2_s\" name=\"passwort2_s\" required/>"+
				"	</div>"+
				"	</td>"+
				"	</tr>"+
	
				
				"</table>"+
				
				"<div>"+
				"	<input type=\"submit\" value=\"Speichern\"/>"+
				"</div>"+
			"</form>";
}


function zweiMit(){
	document.getElementById("tauscher").innerHTML = "" +
			"<form id=\"absolForm\" action=\"/bearbeitenMit/\" method=\"POST\">		"+
				"<table border=\"1\">"+
					
					
					"		<tr>"+
				"	<td>"+
				"	<div>"+
				"		<label for=\"email_s\">E-Mail</label>"+
				"	</div>"+
			"		</td>"+
			"		<td>"+
			"		<div>"+
					"	<input type=\"text\" id=\"email_s\" name=\"email_s\" required/>"+
				"	</div>"+
					"</td>"+
					"</tr>"+
					
				"	<tr>"+
				"	<td>"+
				"	<div>"+
				"		<label for=\"passwort1_s\">Passwort</label>"+
				"	</div>"+
				"	</td>"+
				"	<td>"+
				"	<div>"+
				"		<input type=\"text\" id=\"passwort_s\" name=\"passwort_s\" required/>"+
				"	</div>"+
				"	</td>"+
				"	</tr>"+
					
					
				"</table>"+
				
				"<div>"+
					"<input type=\"submit\" value=\"Speichern\"/>"+
				"</div>"+
			"</form>";
}